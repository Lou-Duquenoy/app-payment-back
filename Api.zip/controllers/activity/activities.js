const { response } = require("express");
const { EmailCampaignsApi } = require("sib-api-v3-sdk");
const activities = require("../../models/activities");
const adressesT = require("../../models/adresses");
const User = require("../../models/User");
const jwt_decode = require("jwt-decode");
//const { Op } = require("sequelize/types");

//Road for create activities
module.exports.addActivity = async (req, res) => {
  try {
    let data = req.body;
    let pictureld = data.pictureld;
    let name = data.name;
    let description = data.description;
    let adresses = data.adresses;
    let categoriesld = data.categoriesld;
    let minimunumPrice = data.minimunumPrice;
    let rate = 0;
    let type = data.type;
    let logo = data.logo;
    let jwt = data.jwt;
    //console.log(jwt);
    let jwtUser = jwt_decode(jwt);
    //console.log(jwtUser);

    let email = jwtUser.email;
    //console.log(email);
    let user = await User.findOne({
      where: {
        email: email,
      },
    }).then((res) => {
      return res;
    });
    //console.log(user);
    let userId = user.id;
    console.log(userId);

    let newActivities = await {
      pictureld: pictureld,
      name: name,
      description: description,
      adressesld: 0,
      ctegoriesld: 0,
      minimunumPrice: minimunumPrice,
      rate: rate,
      type: type,
      logo: logo,
      userId: userId,
      createdAt: Date(),
      updatedAt: Date(),
    };
    let activitiesC = await activities
      .create(newActivities)
      .then((response) => {
        console.log(response);
        return response;
      })
      .catch((err) => {
        return err;
      });
    console.log(activitiesC);
    adresses = {
      streetNumber: adresses.streetNumber,
      streetName: adresses.streetName,
      postCode: adresses.postCode,
      city: adresses.city,
      contry: adresses.contry,
      userId: userId,
      advertisements: 0,
      activityId: activitiesC.id,
    };
    let adresseC = await adressesT
      .create(adresses)
      .then((response) => {
        return response;
      })
      .catch((err) => {
        return err;
      });
    console.log(adresseC);
    await activitiesC.update({ adressesld: adresseC.id });
    /*let idActivite=activitiesC.id;
    
    await adresseC.update({"adressesld":idActivite});*/
    res.json({ activitiesC });
  } catch (err) {
    res.status(400).json({ err });
  }
};

//Road show all activities
module.exports.indexActivities = async (req, res) => {
  try {
    let iActivities = await activities.findAll({
      include: { model: adressesT, required: true },
    });
    console.log(iActivities);
    res.json({ iActivities });
  } catch (err) {
    res.status(400).json({ err });
  }
};

//Road update activities
module.exports.updateMyActivities = async (req, res) => {
  try {
    let data = req.body;
    let activitieId = data.activitieId;
    let jwt = data.jwt;
    let jwtUser = jwt_decode(jwt);
    let user = await User.findOne({
      where: {
        email: jwtUser.email,
      },
    });
    let newInfoActivities = data.updateActivities;
    try {
      let checkactivities = await activities
        .findOne({
          where: {
            id: activitieId,
            userId: user.id,
          },
        })
        .catch((err) => {
          return err;
        });
      if (checkactivities == null) {
        res.json({ message: false });
      } else {
        checkactivities.update(newInfoActivities);
        res.json({ checkactivities });
      }
    } catch (err) {
      res.json({ err });
    }
  } catch (err) {
    res.json({ err });
  }
};

//road show my activities
module.exports.myActivities = async (req, res) => {
  try {
    let data = req.body;
    let jwt = data.jwt;
    let jwtUser = jwt_decode(jwt);
    console.log(jwt);
    let user = await User.findOne({
      where: {
        email: jwtUser.email,
      },
    });
    let userId = user.id;
    let myActivities = await activities.findOne({
      include: { model: adressesT },
      where: { userId: userId },
    });
    console.log(myActivities);
    res.json({ myActivities });
  } catch (err) {
    res.status(400).json({ err });
  }
};

//Road for show one activitie by id
module.exports.showIdActivities = async (req, res) => {
  try {
    let data = req.body;
    let activitieId = data.activitieId;
    let showActivities = await activities.findOne({
      where: { id: activitieId },
    });
    let adresse = await adressesT.findOne({
      where: { id: showActivities.adressesld },
    });
    showActivities = {
      id: showActivities.id,
      pictureld: showActivities.pictureld,
      name: showActivities.name,
      description: showActivities.description,
      contry: adresse.contry,
      city: adresse.city,
      postCode: adresse.postCode,
      streetNumber: adresse.streetNumber,
      streetName: adresse.streetName,
      categoriesld: showActivities.ctegoriesld,
      minimunumPrice: showActivities.minimunumPrice,
      rate: showActivities.rate,
      type: showActivities.type,
      logo: showActivities.logo,
    };
    res.json(showActivities);
  } catch (err) {
    res.status(404).json({ err });
  }
};

//Road find activities by name or city or country
module.exports.findActivities = async (req, res) => {
  let data = req.body;
  let findActivities = data.input;
  let resultActivities = await activities.findAll({
    include: { model: adressesT, required: true },
    where: {
      [Op.or]: [
        {
          name: findActivities,
        },
        { city: findActivities },
        { country: findActivities },
      ],
    },
  });
  res.json({ resultActivities });
};

//road for show the activities proximitie
module.exports.activityProxyUser = async (req, res) => {
  let data = req.body;
  let jwt = data.jwt;
  let geolocalisationUser = data.mygeolocalisation;
  console.log(geolocalisationUser);
  try {
    if (geolocalisationUser == null) {
      let jwtUser = jwt_decode(jwt);
      let user = await User.findOne({
        where: {
          email: jwtUser.email,
        },
      });
      //console.log(user);
      let cityUSer = user.city;
      let adresseUser = cityUSer.split(",");
      console.log(adresseUser);
      /*    const testl = await sequelize.query(
                "SELECT * FROM activities JOIN adressesT ON activities.adressesld = adressesT.id Where adressesT.city="+cityUSer
              ); */
      //let test =await activities.findByLocalite(adresseUser);
      let iActivities = await activities
        .findAll({
          include: { model: adressesT, required: true },
          where: {
            "$adress.city$": adresseUser[0],
          },
        })
        .then((res) => {
          console.log(res);
          return res;
        })
        .catch((err) => console.log(err));
      console.log(iActivities);
      res.json({ iActivities });
    } else {
      res.json({ geolocalisationUser });
    }
  } catch (err) {
    res.json({ err });
  }
};
