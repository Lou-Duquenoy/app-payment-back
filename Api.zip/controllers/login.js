const User = require("../models/User");
const bcrypt = require("bcryptjs");
const generateToken = require("../services/jsonWebToken/generator");

module.exports.login = async (req, res) => {
	
	console.log(" t'es dans le login de new api mon chum");
  // We get the email and password data from the front end form
  try {
    const visitorData = req.body.data;
    console.log("loginController visitorData" + visitorData.email);
	  console.log("loginController visitorData" + visitorData.password);

    // We search into the database for a user with an email equal to the one we got in the front end form
    const userData = await User.findOne({
      where: { email: visitorData.email },
    });

    console.log(" loginController userData ", userData.password);
    // We check if the password we get in the front end form matches with the one in databse for this email
    bcrypt.compare(
      visitorData.password,
      userData.password,
      async function (err, result) {
        // If the password is not correct, we return an error message
        if (!result) {
          visitorData.errors = "Email ou mot de passe invalide";
          res.status(403).json(visitorData.errors);
        } else {
          const token = generateToken(
            {
              email: userData.email,
            },
            res
          );
        }
      }
    );
  } catch (err) {
    console.trace(err);
    res.status(500).json("Connexion failed");
  }
};
