const User = require("../../models/User");
const crypto =  require("crypto");
const uuid = crypto.randomUUID;
const { randomUUID } =require('crypto');
module.exports.generateWalletId = async (req, res) => {
  const findAllUsers = await User.findAll().catch(
    (err) => {
      console.log(err);
    }
  );

  findUser.forEach(async function (item, index, array) {
    const userID = item.dataValues.id;
    console.log(userID);
    const walletId = uuid;
    console.log(walletId);
    const findUser = await User.findOne({where:{id:userID}}).catch(
      (err) => {
        console.log(err);
      }
    );
    findUser.update({ walletId: walletId });
    return "ok";
  });
  res.json({ Message: "Muxed account created" });
};
