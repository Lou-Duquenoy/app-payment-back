const axios = require("axios");
const User = require("../models/User");
const jwt_decode = require("jwt-decode");
require("dotenv").config();
const mailSender = require("../sendinblue/mailSender");
const SibApiV3Sdk = require("sib-api-v3-sdk");

// Authentification Sendinblue
SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;


const config = {
  auth: { username: process.env.UbbleClientId, password: process.env.UbbleClientSecret },
  headers: {
    Accept: "application/vnd.api+json",
    "Content-Type": "application/vnd.api+json",
  },
};

const body = JSON.stringify({
    data: {
      type: "identifications",
      attributes: {
        "redirect-url": "https://fr.ozalentour.com",
      }
    }
  });

module.exports.connectedUbble = async (req,res) => {
  try{
    let data =req.body;
    let jwt=data.jwt;
    let jwtUser=jwt_decode(jwt);
    let user=await User.findOne({where:{
        "email":jwtUser.email
    }})
    let createIdentification =await axios
      .post("https://api.ubble.ai/identifications/", body, config)
      .then((res) => {
        let resultUbble=res.data;
       return resultUbble;
    })
      .catch((err) => console.log(err));
      let idUbble=createIdentification.data.attributes['identification-id'];
      let urlUbble=createIdentification.data.attributes['identification-url'];
      let test=await user.update({ubbleId:idUbble}).then((res)=> {
        return res;
      }).catch(err=> {return err});
        let username=user.firstName+" "+user.lastName;
    let test1= await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
      sender: { email: "inscription@ozalentour.com", name: "Ozalentour" },
      subject: "Vérification KYC ",
      templateId: 75,
      params: {
        URLKYC: urlUbble,
        USERNAME :username
      },
      messageVersions: [
        {
          to: [
            {
              email: jwtUser.email,
            },
          ],
        },
      ],
    });
    res.json({createIdentification});
  }
  catch(err){res.status(404).json({message:false})};
}

module.exports.viewstateUserUbble= async (req,res) => {
  try{
    let data =req.body;
    let jwt=data.jwt;
    let jwtUser=jwt_decode(jwt);
    const user=await User.findOne({where:{
        "email":jwtUser.email
    }});
    const identificationId = user.ubbleId;
    let resultUbble =await axios
      .get("https://api.ubble.ai/identifications/"+identificationId+"/", config)
      .then((res) => {
        let statusUbble=res.data;
       return statusUbble;
    })
      .catch((err) => console.log(err));
      console.log(resultUbble);
      if(resultUbble.data.attributes["score"]===1){
        console.log(user);
        //const newUserPassword = await findUser.update({ password: newPassword });
        await user.update({kyc:true});
        res.status(200).json({message:true});
      }
      else if(resultUbble.data.attributes["score"]===0){
        res.status(400).json({message:"Refuser"})
      }
      else if(resultUbble.data.attributes["score"]===-1){
        res.status(400).json({message:"incomplete"})
      }      
      else if(resultUbble.data.attributes["status"]==="expired"){
        res.status(400).json({message:"Relancer la demande l'url a expirer"})
      }
      else if(resultUbble.data.attributes["status"]==="aborted"){
        res.status(400).json({message:"Relancer la demande l'url a expirer"})
      }
      else{
        res.status(200).json({message:false});
      }
  }
   catch(err){
    res.status(404).json({message:false});
   }
   
}
/* client id=JMIZRWFSKKYP25JIL3KCYHG28QWSWS

client scret=2EVOHR189AQFXQF46937TK7PILTYCSKZRVL5RXJMZF9H9DEPZY */

const whereLangue= (langue,res)=>{
  console.log(langue);
  if(langue=="fr"){
      templateIdL=77;
      return templateIdL;  
  }
  else if(langue=="en"){
      templateIdL=78;
      return templateIdL;
  }
  else if (langue=="es"){
      templateIdL=84;
      return templateIdL;
  }
  else{
      return false;
  }
}