const Stellar_Transaction_History = require("../models/Stellar_Transaction_History");
const Transaction_History = require("../models/Transaction_History");

module.exports.saveTransaction = async () => {
  let transactionData = {
    stellarId: result.id,
    stellarTransactionId: result.id,
    pagingToken: result.paging_token,
    successful: result.successful,
    hash: result.hash,
    ledger: result.ledger,
    createdAt: result.created_at,
    sourceAccount: result.source_account,
    sourceAccountSequence: result.source_account_sequence,
    feeAccount: result.fee_account,
    feeCharged: result.fee_charged,
    maxFee: result.max_fee,
    operationCount: result.operation_count,
    envelopeXdr: result.envelope_xdr,
    // /***!***\ Database expect string, be careful in case of multiple signatures /***!***\
    signatures: result.signatures[0],
  };

  let newTransaction = await Stellar_Transaction_History.createTransaction(
    transactionData,
    res
  ).then(async function () {
    let saveTransaction = await Transaction_History.createTransaction(
      transactionData,
      res
    );
  });
};
