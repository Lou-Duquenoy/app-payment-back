const { response } = require("express");
const Transaction_History = require("../models/Transaction_History");
/* const stripe= require('../node_modules/stripe'); */
const axios =require("axios");
const Stripe = require('stripe');
const stripe = require("stripe")(
  "sk_test_51KSqQNLfhyRdEQSdXNQUpOwvmoYsf6LZF1n6sAquKDKxYmKNrOoWBsUXkySn0JVoGzcxe39wAs4AV2zD6LnRzQ3L003nvhS8ZZ",
);
//sk_test_51KTb1TBiquqamXIFYW2jy2KBbwiv3KdrD8y8PwzFavm1l38Rfd7vlvf55T4uapWn6YBsOlouoeavMEn36saj8w0p004bMuYnZK",{ stripeAccount: "acct_1KTb1TBiquqamXIF" }	
module.exports.createPayementIntent = async (req, res) => {
  let data = req.body;
	console.log(data);
  let amountnotaxe = data.amount;
  let amountnotaxeStripe=amountnotaxe*100
	console.log(amountnotaxe);
  let amounttaxe = amountnotaxeStripe / 0.99;
  console.log(amounttaxe);
  amounttaxe = parseInt(amounttaxe, 10);
  let currency = data.currency;
  console.log(amountnotaxe, amounttaxe);
  /*  res.json({amounttaxe}); */
	const paymentIntent = await stripe.paymentIntents.create({
  amount: 2000,
  currency: 'eur',
  payment_method_types: ["sepa_debit"],

});
  const paymentInt = await stripe.paymentIntents
    .create({
      amount: amounttaxe,
      currency: currency,

      payment_method_types: [
        "bancontact",
        "card",
        //"eps",
        //"giropay",
        //"ideal",
        //"p24",
        "sepa_debit",
        //"sofort",
      ],
      //stripe dashboard description
      description: "achat de " + amountnotaxe + " OZP",
      //bank record. 22 chars max.
      statement_descriptor: "Ozalentour: " + amountnotaxe + "OZP".substr(0, 22),
      //customized metadata
      metadata: {
        product: "OZP",
		account_holder_name: "Demo Test Inc.",
    bic: "CITINL2XXXX",
    country: "FR",
    iban: "FR1420041010050500013M02606"
      },
    })
    .then((response) => {
		console.log(response);
      return response;
    });
  res.json(paymentInt);
};

module.exports.payementVir = async (req, res) => {
	/*const test = stripe.confirmSepaDebitPayment("pi_3M1XlqBiquqamXIF0i0BqPS9",{
	payment_method: {
      sepa_debit: {
		   iban: "FR1420041010050500013M02606",
	  },
      billing_details: {
        name: 'Jenny Rosen',
        email: 'jenny@example.com',
      },
    },
	});
	console.log(test);*/
	const lol= await axios.post('https://api.stripe.com/v1/setup_intents', {
	
  "iban": {
    "account_holder_name": "Demo Test Inc.",
    "bic": "CITINL2XXXX",
    "country": "FR",
    "iban": "FR1420041010050500013M02606"
  },
  "supported_networks": [
    "sepa"
  ],
  "type": "iban"

});
	console.log(lol);
}

  module.exports.createPayementIntentVir = async (req, res) => {
	  
	
	  const source = await stripe.sources.create({
  type: 'sepa_debit',
  sepa_debit: {iban: 'FR1420041010050500013M02606'},
		  amount:5411,
  currency: 'eur',
customer:"PSSTFRPPLIL",
  owner: {
    name: 'Jenny Rosen',
    address: {
      city: 'Lambersart',
      country: 'FR',
      line1: 'rue 24',
      postal_code: '59190',
      state: 'France',
    },
  },
});
	  /*
	const charge = await stripe.charges.create({
  amount: 1099,
  currency: 'eur',
     automatic_payment_methods: {
      enabled: true,
    },

});  */
	 res.json(payout);
	/*  const paymentIntent = await stripe.paymentIntents.create({
  amount: 2000,
  currency: 'EUR',
  payment_method_types: ['sepa_debit'],
}).then(result=>{console.log(result,"mieux ?"); res.json(result)});*/
	  /*const customer = await stripe.customers.create();
	  console.log(customer);
	const intent = await stripe.paymentIntents.create({
  amount: 100,
  currency: 'eur',
  customer: customer.id,
  payment_method_types: ['customer_balance'],
  payment_method_data: {
    type: 'customer_balance',
  },
  payment_method_options: {
    customer_balance: {
      funding_type: 'bank_transfer',
      bank_transfer: {
        type: 'eu_bank_transfer',
        eu_bank_transfer: {
          country: 'FR',
		     bank_code: 'AT611904300234573201',
        }
      },
    },
  },
  confirm: true,
}).then(result=>{console.log(result,"test"); res.json(result)});*/
  }

/*   //app.get('/create-setup-intent',
    module.exports.createStripe = async (req, res) => {
    const customer = await stripe.customers.create()
    const intent = await stripe.setupIntents.create({
      payment_method_types: ['card'],
      customer: customer.id,
    });
    console.log(intent);
    res.json({message:"bonjour"});
  }

  //app.post('/create-checkout-session',
  module.exports.checkoutStripe = async (req, res) => {
    console.log(req.body);
    let testamount = parseInt(req.body.text)
    //console.log(testamount)
    let email= req.body.email;
    let jenuc= [];
    let montatstripe= testamount/0.99;
    montatstripe=montatstripe-testamount;

    console.log(montatstripe);
    const session = await stripe.checkout.sessions.create({
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: {
            name: 'OZP',
            
            },
            'unit_amount':100,
            
          },
          quantity: testamount,
        },
      ],
      mode: 'payment',
      success_url: 'http://prodtest.ozalentour.com/confirmation.php/?amount='+testamount,
      cancel_url: 'http://localhost:4242/cancel',
    });
     console.log(session);
     jeanuc=session.id;
     console.log(jeanuc);
     const transaactionData={
      userSender:"Ozalentour",
      userRecipient:email,
      amount:testamount,
      currency:"OZP",
      type:1,
      method:1,
      externalId:session.id,
      stateExternal:"en attente",
    };
    let saveTransaction = await Transaction.create(
      transaactionData
    );
   /* const sessionRetrieved = await stripe.checkout.sessions.retrieve(
      `${session.id}`
     );
     console.log(sessionRetrieved)    
    
    res.redirect(303, session.url);
  }; */
