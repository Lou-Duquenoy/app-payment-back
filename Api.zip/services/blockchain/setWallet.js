const { Account, MuxedAccount } = require("stellar-sdk");
const User = require("../../models/User");

module.exports.setWallet = async () => {
  const id = req;
  const findUser = await User.findOne({ where: { id } }).catch((err) => {
    console.log(err);
  });
  //We generate the muxed account id with the new user id from database
  const muxedAccountId = id.toString();
  const publicKey = "GAHKSSDVMCVRPEFKE7GXJQNZN4EVJBZ6NCQYC3ZNSIJD4B2AKRLUHB3N";

  //We create a muxed account with Stellar
  const muxedAccount = new MuxedAccount(
    new Account(publicKey, "0"),
    muxedAccountId
  );
  // We save the muxed account key
  userPublicKey = muxedAccount.accountId();
  // We update the user table to insert the muxed account public key
  findUser.update({ publicKey: userPublicKey });
};

User.getUserRecipient = async (userData, res) => {
  const publicKey = userData;
  console.log(" User model userData", publicKey);

  const user = await User.findOne({ where: { publicKey: publicKey } }).catch(
    (err) => {
      console.log(err);
    }
  );

  console.log(" User model user", user.dataValues);
  res.json(user.dataValues);
};
