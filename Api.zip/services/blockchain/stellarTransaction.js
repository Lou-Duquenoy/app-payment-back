const StellarSdk = require("stellar-sdk");
const Stellar_Transaction_History = require("../../models/Stellar_Transaction_History");
let server = new StellarSdk.Server("https://horizon-testnet.stellar.org");
let sourceKeys = StellarSdk.Keypair.fromSecret(
  "SACJRGGZXPLGHMZNNGG7EVXLDBHPZG4X37J2DSLBRRXEM325JPLR622P"
);

const OZPTEST = new StellarSdk.Asset(
  "OZPTEST",
  "GDXHUEM5FBAJCAS3FDHVT66222PQQ6M7IFQNRVGLFK5N5265W7K25HBH"
);

let channelSecretKey = [
  "SD4LEPHKUSMDJHXENRQE44YMBGKD2AVFIMAWZNRFN64AH35P6NMQQRPU",
  "SAVC7S7R4UZJVP7KKPN526RXSQ4CIZE75ENREVYDCKQ2PCFIGKOM4NBU",
  "SCIWPQTUPXP6WQPM6IUB7DTJXZ7GCOZN55MZEUNGPTB5YGJSCFPLDFQI",
  "SCQEUAT7PC326CYAHMDOPQEUXTIMRIWX357SCBYXJL7DMN4POAI2DHYQ",
  "SCIFQHB5B24RPFOOUINEAG4ZUEE5SSXY4DHRKUZCB75JRZGGZXNKLYVX",
  "SA2Q4QJIO2FXAZWX2GBIBZJSAFQ2YRCUKRRCHISUYKZATMZTGERTFES2",
  "SAWCBZXLWBLJVHBRM263MPO7DIYZM5T6XZLP56XDQAQSUBHJVPSI2ECJ",
  "SC4RJJXZALAJV7BGE5OUO6OAICTAACMVICQZDF63LG53NNVCZ22UVGKN",
  "SC7R2V27RISZ3FMOT4GLLBSO735RPO2BWIIW25GUPUZRLNMWHWKYWKCA",
  "SCCSHG5Y23WP3VKJBGW72W2OZPLNWE7BQB2FUG5MZDUAKDXAWEVHYIL5",
];

// Transaction will hold a built transaction we can resubmit if the result is unknown.
let transaction = null;

module.exports.stellarTransaction = (stellarReceiverKey, stellarAmount) => {
  let key = Math.floor(Math.random() * 10);
  let channelkey = channelSecretKey[key];

  let channelkeys = StellarSdk.Keypair.fromSecret(channelkey);

  try {
    return (
      server
        .loadAccount(stellarReceiverKey)
        // If the account is not found, surface a nicer error message for logging.
        .catch(function (error) {
          if (error instanceof StellarSdk.NotFoundError) {
            throw new Error("The destination account does not exist!");
          } else return error;
        })
        // If there was no error, load up-to-date information on your account.
        .then(function () {
          return server.loadAccount(channelkeys.publicKey());
        })
        .then(function (sourceAccount) {
          // Start building the transaction.
          transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
            fee: StellarSdk.BASE_FEE,
            networkPassphrase: StellarSdk.Networks.TESTNET,
          })
            .addOperation(
              StellarSdk.Operation.payment({
                destination: stellarReceiverKey,
                source:
                  "GAHKSSDVMCVRPEFKE7GXJQNZN4EVJBZ6NCQYC3ZNSIJD4B2AKRLUHB3N",
                // Because Stellar allows transaction in many currencies, you must
                // specify the asset type. The special "native" asset represents Lumens.
                asset: OZPTEST,
                amount: stellarAmount,
              })
            )
            // A memo allows you to add your own metadata to a transaction. It's
            // optional and does not affect how Stellar treats the transaction.

            // Wait a maximum of three minutes for the transaction
            .setTimeout(180)
            .build();
          // Sign the transaction to prove you are actually the person sending it.
          transaction.sign(sourceKeys);
          transaction.sign(channelkeys);
          // And finally, send it off to Stellar!
          return server.submitTransaction(transaction);
        })
        .then(async function (result) {
          console.log("RETOUR DE STELLAR", result);

          let stellarTransactionData = {
            stellarId: result.id,
            stellarTransactionId: result.id,
            pagingToken: result.paging_token,
            successful: result.successful,
            hash: result.hash,
            ledger: result.ledger,
            createdAt: result.created_at,
            sourceAccount: result.source_account,
            sourceAccountSequence: result.source_account_sequence,
            feeAccount: result.fee_account,
            feeCharged: result.fee_charged,
            maxFee: result.max_fee,
            operationCount: result.operation_count,
            envelopeXdr: result.envelope_xdr,
            // /***!***\ Database expects string, be careful in case of multiple signatures /***!***\
            signatures: result.signatures[0],
          };

          let newTransaction = await Stellar_Transaction_History.create(
            stellarTransactionData
          );

          return (stellarStatus = result.successful);
        })
    );
  } catch (error) {
    console.error(error);
  }

  return stellarStatus;
};
