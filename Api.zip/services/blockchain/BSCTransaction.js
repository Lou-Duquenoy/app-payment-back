const Web3 = require("web3");
//Inport or fs in order to read Abi.json
const fs = require("fs");
const path = require("path");

module.exports.BSCTransaction = async (BSCReceiverKey, BSCAmount) => {
  try {
	 
    //Connexion on web3 and BSC
    const web3 = new Web3(
      new Web3.providers.HttpProvider(
        "https://data-seed-prebsc-1-s1.binance.org:8545"
      )
    );

    const contractJson = fs.readFileSync(
      path.resolve(__dirname, "./contract.json")
    );
    const abi = JSON.parse(contractJson);

    //estimation of gaz price
    const gasprice = await web3.eth.getGasPrice();
    //The wallet account
    const myAccount = "0x841933e6c572e90b2D484e91112893D3E92Bd4d4";
    //we get the number of the wallet transaction
    const nonce = await web3.eth.getTransactionCount(myAccount);

    //this is the instance of the contract
    const token = new web3.eth.Contract(
      abi,
      "0x9c86d4e1FfF531B3b2F7a6DF80AB6AF4d1CC32e2"
    );

    const privateKey =
      "265f81ddbb648dc97ae9176d699c40dee443dc2c1eec57dd2e553a58098596f0";

    //Transaction object//will be sent on chain
    const txObject = {
      from: myAccount,
      nonce: "0x" + nonce.toString(16),
      to: "0x9c86d4e1FfF531B3b2F7a6DF80AB6AF4d1CC32e2",
      gas: 200000,
      value: "0x0",
      data: token.methods
        .transfer(
          BSCReceiverKey,
          web3.utils.toHex(web3.utils.toWei(BSCAmount.toString(), "ether"))
        )
        .encodeABI(),
      gasPrice: gasprice,
    };
 

	  
    //Signature de la transaction
  let BSCInfos = await web3.eth.accounts.signTransaction(txObject, privateKey, (err, res) => {

      const raw = res.rawTransaction;
	let result;
      //Envoi de la transaction
      web3.eth.sendSignedTransaction(raw, (err, txHash) => {
     //console.log("txHash", txHash);
		result = txHash;
      })
	 
    })
	  return BSCInfos;
	 
  } catch (error) {
    console.error(error);
	   let transactionInfos = {"status": false, "message": "BSC transaction failed"}
	return transactionInfos
  }
	
};
