require("dotenv").config();
const VerificationKey = require("../models/VerificationKey");
const SibApiV3Sdk = require("sib-api-v3-sdk");
const sendRegisterEmailCodeAgain = require("./languageTemplate");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.resendRegisterEmailCode = async (data, res) => {
  try {
    let email = data.email;
    let language = data.language;
    console.log("userController userEmail", email);
    let templateId = sendRegisterEmailCodeAgain(language);

    const findVisitor = await VerificationKey.findOne({
      where: { data: email },
    }).catch((err) => {
      console.log(err);
    });

    let visitorCode = findVisitor.key;

    console.log("userController j'ai trouvé le user", findVisitor);

    await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
      sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
      subject: templateId.templateIdSubjetResendPass,
      templateId: templateId.templateIdSendAgain,
      params: {
        USERPASSWORD: visitorCode,
      },
      messageVersions: [
        {
          to: [
            {
              email: email,
            },
          ],
        },
      ],
    });

    res.json({ message: "Votre code a été envoyé" });
  } catch (err) {
    console.log(err);
    res.status(500).json("Server error");
  }
};

const whereLangue = (langue, res) => {
  console.log(langue);
  if (langue == "fr") {
    let templateid = {
      templateIdSendAgain: 70,
      templateIdSubject: "Confirmez votre email",
    };
    return templateid;
  }
  if (langue == "en") {
    let templateid = {
      templateIdSendAgain: 81,
      templateIdSubject: "Confirm your email",
    };
    return templateid;
  }
  if (langue == "esp") {
    let templateid = {
      templateIdSendAgain: 87,
      templateIdSubject: "Confirme su correo electrónico",
    };
    return templateid;
  } else {
    let templateid = {
      templateIdSendAgain: 81,
      templateIdSubject: "Confirm your email",
    };
    return templateid;
  }
};
