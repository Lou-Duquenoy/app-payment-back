const SibApiV3Sdk = require("sib-api-v3-sdk");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;


module.exports.resetPasswordEmail = async (password, email) => {

    await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
        sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
        subject: "Votre mot de passe",
        templateId: 68,
        params: {
          USERPASSWORD: password,
        },
        messageVersions: [
          {
            to: [
              {
                email: email,
              },
            ],
          },
        ],
      });
}