const SibApiV3Sdk = require("sib-api-v3-sdk");
const { resetPasswordLink } = require("./languageTemplate");

// Authentification Sendinblue
SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.resetPasswordLink = async (language, email, token) => {
  let template = resetPasswordLink(language);

  let url = `https://${language}.ozalentour.com/resetPassword/?token=${token}`;

  await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
    sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
    subject: template.subject,
    templateId: template.passwordLink,
    params: {
      VERIFICATIONURL: url,
    },
    messageVersions: [
      {
        to: [
          {
            email: email,
          },
        ],
      },
    ],
  });
};
