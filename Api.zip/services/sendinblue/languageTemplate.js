module.exports.contactOzaTeam = (language) => {
  console.log(language);

  if (langue == "fr") {
    return {
      sendMessage: 98,
      confirm: 99,
      subject: "Votre demande à été prise en compte",
    };
  } else if (langue != "fr") {
    // English template
    return {
      sendMessage: 100,
      confirm: 101,
      subject: "Your request is taken into account",
    };
  }
};

module.exports.register = (language) => {
  if (language == "fr") {
    return {
      sendCode: 70,
      subject: "Confirmez votre email",
    };
  }
  if (language == "esp") {
    return {
      sendCode: 87,
      subject: "Confirmez votre email",
    };
  }
  if (language != "fr" && language != "es") {
    return {
      sendCode: 81,
      subject: "Confirmez votre email",
    };
  }
};

module.exports.registerSuccess = (language) => {
  if (language == "fr") {
    return {
      createUser: 69,
      subject: "Votre compte a été créé",
    };
  }
  if (language == "esp") {
    return {
      createUser: 85,
      subject: "Su cuenta está creada",
    };
  }
  if (language != "fr" && language != "es") {
    return {
      createUser: 79,
      subject: "Your account has been created",
    };
  }
};

module.exports.resetPasswordLink = (language) => {
  if (language == "fr") {
    return {
      passwordLink: 72,
      subject: "Demande de réinitialisation du mot de passe",
    };
  }
  if (language == "esp") {
    return {
      passwordLink: 88,
      subject: "Solicitud de restablecimiento de contraseña",
    };
  }
  if (language != "fr" && language != "es") {
    return {
      passwordLink: 82,
      subject: "Request for password reset",
    };
  }
};
