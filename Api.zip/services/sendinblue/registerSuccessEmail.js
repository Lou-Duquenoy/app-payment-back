require("dotenv").config();
const SibApiV3Sdk = require("sib-api-v3-sdk");
const { registerSuccess } = require("./languageTemplate");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.registerSuccessEmail = async (data, res) => {

  console.log("User email for sendinblue", data.email);
  let templateId = registerSuccess(language = "fr");

  let notifSuccess = await new SibApiV3Sdk.TransactionalEmailsApi()
    .sendTransacEmail({
      sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
      subject: templateId.subject,
      templateId: templateId.createUser,
      params: {
        USERNAME: data.userName,
      },
      messageVersions: [
        {
          to: [
            {
              email: data.email,
            },
          ],
        },
      ],
    })
    .catch((err) => {
      console.log(err);
    })
    	if (notifSuccess) {
			let notifSuccess = {"status": 200, "message": "Email sent to the new user"};
			
			return notifSuccess
	}
};
