require("dotenv").config();
const SibApiV3Sdk = require("sib-api-v3-sdk");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.registerNotifOzaTeam = async (data, res) => {
  let notifOza = await new SibApiV3Sdk.TransactionalEmailsApi()
    .sendTransacEmail({
      sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
      subject: "Un nouvel utilisateur vient de s'inscrire",
      templateId: 102,
      params: {
        USERNAME: data.username,
        EMAIL: data.email,
        SOCIETE: data.company,
      },
      messageVersions: [
        {
          to: [
            {
              email: "info@ozalentour.fr",
            },
          ],
        },
      ],
    })
    .catch((err) => {
      console.log(err);
    })
		if (notifOza) {
			let notifResponse = {"status": 200, "message": "Email sent to the Oza team"};
			
			return notifResponse
	}
  
 
};
