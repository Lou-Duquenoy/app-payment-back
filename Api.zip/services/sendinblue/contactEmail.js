require("dotenv").config();
const SibApiV3Sdk = require("sib-api-v3-sdk");
const { contactOzaTeam } = require("./languageTemplate");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.contactEmail = async (data, res) => {
  let template = contactOzaTeam(data.language);

  try {
    let sendMessageToOzaTeam = await new SibApiV3Sdk.TransactionalEmailsApi()
      .sendTransacEmail({
        sender: { email: "info@ozalentour.com", name: "Ozalentour" },
        subject: "Demande de contact de " + userName,
        templateId: template.sendMessage,
        params: {
          EMAIL: data.email,
          USERNAME: data.userName,
          MESSAGE: data.message,
          SOCIETE: data.company,
          PHONE: data.phone,
        },
        messageVersions: [
          {
            to: [
              {
                email: "info@ozalentour.com",
              },
            ],
          },
        ],
      })
      .catch((error) => {
        console.error(error);
        res.status(500).json("Can't send message to Oza team");
      })
      .then(async () => {
        let confirmReception =
          await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
            sender: { email: "info@ozalentour.com", name: "Ozalentour" },
            subject: template.subject,
            templateId: template.confirm,
            params: {
              USERNAME: userName,
            },
            messageVersions: [
              {
                to: [
                  {
                    email: data.email,
                  },
                ],
              },
            ],
          });
      })
      .catch((error) => {
        console.error(error);
        res.status(500).json("Can't send contact email confirmation");
      })
      .then(() => {
        res
          .status(200)
          .json("Request sent to Oza team and confirmationn sent to the user");
      });
  } catch (error) {
    console.error(error);
  }
};
