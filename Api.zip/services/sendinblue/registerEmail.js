require("dotenv").config();
require("dotenv").config();
const SibApiV3Sdk = require("sib-api-v3-sdk");
const { register } = require("./languageTemplate");
const Verification_Key = require("../../models/Verification_Key");
const User = require("../../models/User");

SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

let charset = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

// We send an email at the adress we get from the front end form with a 6 character code
module.exports.registerEmail = async ({ email, language }, res) => {
  let template = register(language);
  let verificationCode = "";

  for (i = 0; i <= 5; i++) {
    verificationCode += charset.charAt(
      Math.floor(Math.random() * charset.length)
    );
  }
  const findVisitor = await Verification_Key.findOne({
    where: { data: email },
  }).catch((err) => {
    console.log(err);
  });

  const checkIfUserExists = await User.findOne({
    where: { email: email },
  }).catch((err) => {
    console.log(err);
  });

  if (checkIfUserExists) {
    res.status(500).json("A user with this email already exists");
  } else if (findVisitor) {
    let visitorCode = findVisitor.key;

    new SibApiV3Sdk.TransactionalEmailsApi()
      .sendTransacEmail({
        sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
        subject: template.subject,
        templateId: template.sendCode,
        params: {
          CODEMAIL: visitorCode,
        },
        messageVersions: [
          {
            to: [
              {
                email: email,
              },
            ],
          },
        ],
      })
      .then(() => {
        res.status(200).json("Email sent");
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't send email code");
      });
  } else {
    Verification_Key.create({
      key: verificationCode,
      data: email,
    })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't save email code");
      })
      .then(() => {
        new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
          sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
          subject: template.subject,
          templateId: template.sendCode,
          params: {
            CODEMAIL: verificationCode,
          },
          messageVersions: [
            {
              to: [
                {
                  email: email,
                },
              ],
            },
          ],
        });
      })
      .then(() => {
        res.status(200).json("Email sent");
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't send email code");
      });
  }
};
