require("dotenv").config();
const Verification_Key = require("../../models/Verification_Key");
const SibApiV3Sdk = require("sib-api-v3-sdk");
const defaultClient = SibApiV3Sdk.ApiClient.instance;

let apiKey = defaultClient.authentications["api-key"];
apiKey.apiKey = process.env.SENDINBLUE_API_KEY;

let apiInstance = new SibApiV3Sdk.TransactionalSMSApi();

let sendTransacSms = new SibApiV3Sdk.SendTransacSms();

let charset = "0123456789";

// We send a sms at the phone number we get from the front end form with a 6 character code
module.exports.registerSMS = async (visitorPhone, res) => {
  let verificationCode = "";
  console.log(visitorPhone);

  for (i = 0; i <= 5; i++) {
    verificationCode += charset.charAt(
      Math.floor(Math.random() * charset.length)
    );
  }

  const findVisitor = await Verification_Key.findOne({
    where: { data: visitorPhone },
  }).catch((err) => {
    console.log(err);
  });

  if (findVisitor) {
    let visitorCode = findVisitor.key;

    sendTransacSms = {
      sender: "Ozalentour",
      recipient: visitorPhone,
      content:
        "Bonjour,   \r\nUtilisez le code " +
        visitorCode +
        " pour l'authentification à deux facteurs sur Ozalentour. \r\nA bientôt !",
    };

    apiInstance
      .sendTransacSms(sendTransacSms)
      .then(() => {
		res.status(200).json("SMS sent");
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't send SMS");
      });
  } else {
    sendTransacSms = {
      sender: "Ozalentour",
      recipient: visitorPhone,
      content:
        "Bonjour,   \r\nveuillez entrer le code " +
        verificationCode +
        " pour vérifier votre téléphone et poursuivre votre inscription \r\nA bientôt !",
    };

    Verification_Key.create({
      key: verificationCode,
      data: visitorPhone,
    })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't save SMS");
      })
      .then(() => {
        apiInstance.sendTransacSms(sendTransacSms);
      })
      .then(() => {
        res.status(200).json("SMS sent");
      })
      .catch((error) => {
        console.log(error);
        res.status(500).json("Can't send SMS");
      });
  }
};
