const SibApiV3Sdk = require("sib-api-v3-sdk");

// Authentification Sendinblue
SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
  process.env.SENDINBLUE_API_KEY;

module.exports.resetPasswordCode = async (language, email, token) => {
	
	let template = !language ? 104 : 105
console.log("email dans sendinblue resetPassword", email);
	console.log("token dans sendinblue resetPassword", token);
  await new SibApiV3Sdk.TransactionalEmailsApi().sendTransacEmail({
    sender: { email: "no-reply@ozalentour.com", name: "Ozalentour" },
    subject: "Réinitialisation de votre mot de passe",
    templateId: template,
    params: {
      CODE: token,
    },
    messageVersions: [
      {
        to: [
          {
            email: email,
          },
        ],
      },
    ],
  });
};
