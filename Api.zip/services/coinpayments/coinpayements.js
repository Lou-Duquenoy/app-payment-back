const pb="633df371c13a63865a2c59eb2d298ab42b1af3014e767a03b5867116288c31d1";
const pk="27fcE6b675dcB6aCA17e19594d3a9d6749959b0d9d3865fEED7e73BbC7c55281";
const Coinpayments =require("coinpayments");
const User = require("../models/User");
const Transaction = require("../models/Transaction");
const { convertToType } = require("sib-api-v3-sdk/src/ApiClient");
//const CC = require('currency-converter-lt');
const { where, and } = require("sequelize");
const feeCoinpayement=0.9911;
const histoTransactionUsers=require('../models/UsersTransactions');
const StellarSdk = require("stellar-sdk");
const StellarTransaction = require("../models/StellarTransaction");
const TransactionContr=require('./transactionController');


let server = new StellarSdk.Server("https://horizon-testnet.stellar.org");
const sourceKeys = StellarSdk.Keypair.fromSecret(
  "SBOR3ALD5EX6YPJMHQUVQZIDMOQ7R22ECJWPM5FCABB2LMCUFEATC7RM"
);


const OZATEST = new StellarSdk.Asset(
  "OZP",
  "GBUYBCQZGLGYU4YNINZVWSQLMESCR3BIWCO6GVNQVPHGR62S2PC3NT7B"
);
let stellarTransactionId = null;
const CoinpaymentsCredentials = new Coinpayments({
    key: pb,
    secret: pk
  })
const sourceAccount = "GCBYLBE6HSAUP5LFTWJTBFERBHJD736GDNPYCNOAP2IASENBNYSGCATQ";
  // Transaction will hold a built transaction we can resubmit if the result is unknown.
let transaction = null;
/*   const CoinpaymentsGetProfileOpts ={
    pbntag: string
  } */
console.log(CoinpaymentsCredentials)

//Module pour afficher les infos marchand d'ozalentour
module.exports.testCoin1= async (req, res) => {
  const test =await CoinpaymentsCredentials.getBasicInfo()/* .then((res)=>{*/

  console.log(test);
  const emailcoinpayement=test.email;
  const merchantId=test.merchant_id;
  res.json({ 
    email: emailcoinpayement,
    merchandId: merchantId
  })
}

//module pour afficher les différentes crypto ainsi que leur montant 
  module.exports.cryptoPrice= async (req, res) => {
    const cryptoprice =await CoinpaymentsCredentials.rates()
    res.json({cryptoprice});
  }

  //Module pour connaitre notre portefeuille
  module.exports.coinBalancesCrypto=async (req,res)=>{
    const coinBalancesCrypto=await CoinpaymentsCredentials.balances()
    res.json({coinBalancesCrypto});
  }


  //module pour créer une transaction
  module.exports.coinpayementTransactionCreate= async (req,res) => {
  const userData = await  User.getUser(req.body.buyerEmail);
  const userSender=userData.publicKey;
    //partie data send request

    let amountOZP=  req.body.amount/feeCoinpayement;

    let buyerEmail= req.body.buyerEmail;
    let currency1=req.body.currency1;
    let currency2= req.body.currency2;
    const dateData=Date.now(-3);
    const CoinPayementsTransactionCreateOPTS={
      currency1: currency1,
      currency2: currency2,
      amount: amountOZP,
      buyer_email: buyerEmail,
      success_url:"https://localhost:8010/coin/successtransaction?id="+userSender+"?date="+dateData,
      cancel_url:"https://localhost:8010/coin/canceltransaction?id="+userSender+"?date="+dateData,
    };
    //console.log(CoinPayementsTransactionCreateOPTS);
    const coinpayementTransactionCreate= await CoinpaymentsCredentials.createTransaction(CoinPayementsTransactionCreateOPTS);
    const transaactionData={
      userSender:"Ozalentour",
      userRecipient:userSender,
      amount:amountOZP*feeCoinpayement,
      currency:"OZP",
      type:1,
      method:1,
      externalId:coinpayementTransactionCreate.txn_id,
      stateExternal:"en attente",
      createdAt:dateData,
    };
    let saveTransaction = await Transaction.create(
      transaactionData
    );

   let test ={success_url:"https://localhost:8010/coin/successtransaction?id="+userSender+"?date="+dateData,}
   res.json({coinpayementTransactionCreate,saveTransaction, test, dateData});
  }

  //Module pour conaitre l'informations d'une transaction
  module.exports.getTransactionInfoCoin= async (req,res) => {
    //const txid=req.body.txid;
    const txid=req;
    const getTxOptsCoinpaymenets= {
      txid: txid 
    };
    const getxt= await CoinpaymentsCredentials.getTx(getTxOptsCoinpaymenets);
    res.json({getxt});
    //return getxt;
  }

    //Module pour conaitre l'informations d'une transaction
    module.exports.getTransactionInfoCoinV= async (req,res) => {
      //const txid=req.body.txid;
      const txid=req;
      const getTxOptsCoinpaymenets= {
        txid: txid 
      };
      const getxt= await CoinpaymentsCredentials.getTx(getTxOptsCoinpaymenets);
      //res.json({getxt});
      return getxt;
    }
//module pour verifier si il a des transaction en attente qui doivent passé en annulé ou completed
  module.exports.verifyStateTransaction= async (req,res) => {
    let gettransacpending =await Transaction.getTransactionpending();
   //console.log(test);
   let gettransacpendinglenght=gettransacpending.length;
   console.log(gettransacpendinglenght);
   const michel=JSON.stringify(gettransacpending)
   let michella= JSON.parse(michel);
    for (i=0; i<gettransacpendinglenght; i++){
      //console.log(michella[i]);
      let externalID= michella[i]['externalId'];
      const idtransaction= michella[i]['id'];
      let amountOZZZPP= michella[i]['amount']
     let coinpayement= await this.getTransactionInfoCoinV(externalID);
      //console.log(coinpayement);
      //console.log(externalID);
      let statusText=coinpayement.status_text;
      //console.log(statusText);
      statusText="Complete";
      if (statusText === 'Cancelled / Timed Out') {
        //console.log('modifier la transaction par annulé');
        //console.log('est le gagnant est :'+idtransaction);
        const findTransaction = await Transaction.findOne({ where: { id: idtransaction } }).catch((err) => {
          console.log(err);
        });
        console.log(findTransaction);
        findTransaction.update({ stateExternal: "Cancelled" });
      }
      else if (statusText === 'Complete'){
        //console.log("accepted");
        const findTransaction = await Transaction.findOne({ where: { id: idtransaction } }).catch((err) => {
          console.log(err);
        });
        findTransaction.update({ stateExternal: "Completed" });
        console.log(findTransaction.userSender);
        const user = await User.findOne({
          where: { publicKey: findTransaction.userSender },
        }).catch((err) => {
          console.log(err);
        });
        let totalOZP = user.OZP + parseInt(amountOZZZPP);
        const userTotalOZP = await user.update({ OZP: totalOZP });
      }
      else{ 
        console.log("rien ne change")
      }
    }
    /* if (test){
      console.log(test);
    } */
    res.json(test);
  }

  module.exports.transactionIsSucceful= async (req,res) =>{
    console.log(req);
  }
  
module.exports.successtransaction =async (req,res)=>{
  let url=req.url;
  let idtransaction=url.split('='|| '?');
  let iduser=idtransaction[1];
  let datatransaction=idtransaction[2];
   datatransaction=datatransaction; 
   datatransaction= new Date(datatransaction-4);
  iduser=iduser.split('?');
  iduser=iduser[0];
  console.log(datatransaction, iduser);
  let gettransacpending =await Transaction.findAll({ where: {
    stateExternal:"en attente",
    userRecipient:iduser,
    createdAt: datatransaction
  }
  }).catch((err)=>{
    console.log(err);
  });
  //console.log(gettransacpending);
  if (gettransacpending.length>=2){
    for (i=0; i<gettransacpending.length; i++){
      let externalID= gettransacpending[i]['externalId'];
      let amountOZP= gettransacpending[i]["dataValues"].amount;
      let stellarAmountOZP= amountOZP.toString();
      let coinpayement= await this.getTransactionInfoCoinV(externalID);
      let statuscoinpayement=coinpayement.status;
      //on verifie le code du status chez coinpayement
      if (statuscoinpayement==100)
      { 
        //on recherche la transaction de cette id de coinpayement 
        let findTransaction1 = await Transaction.findOne({where: {
          stateExternal:"en attente",
          externalId:externalID,
          userRecipient:iduser
        }}).catch((err) => {
          console.log(err);
        });

        TransactionContr.addRechargeTransactionCrypto(findTransaction1);
        let changeStatusCompleted= "Completed";
        findTransaction1.update({stateExternal:changeStatusCompleted});
        let usertransaction = await User.findOne({
          where: { publicKey: iduser },
        }).catch((err) => {
          console.log(err);
        });

        let oldOzp=usertransaction.OZP;
        let totalOZP = usertransaction.OZP + parseInt(findTransaction1.amount);
        let userTotalOZP = await usertransaction.update({ OZP: totalOZP });
        let transactiondata= {
          userId:iduser,
          transactionid:externalID,
          oldozp:oldOzp,
          newozp:totalOZP
        }
        let histoTransactionUser= await histoTransactionUsers.createHistoUserTransaction(transactiondata);
        res.status(200).json({message: "Mise à jours faite"});
      }
      else{
        res.status(500).json({message:"Erreur avec coinpayement"});
      }
    }   
  }
  else if(gettransacpending.length==1) {
            let externalID= gettransacpending[0]["dataValues"].externalId;
            let amountOZP= gettransacpending[0]["dataValues"].amount;
            let stellarAmountOZP= amountOZP.toString();
            console.log(externalID, amountOZP);
            let coinpayement= await this.getTransactionInfoCoinV(externalID);
            let statuscoinpayement=coinpayement.status;
            console.log(coinpayement);
            let textcoinpayement= coinpayement.status_text;
            //console.log("l'etat du payement est "+statuscoinpayement+" avec comme retour e coinpayement" +textcoinpayement);
            //on verifie le code du status chez coinpayement
            if (statuscoinpayement==100)
            { 
              //on recherche la transaction de cette id de coinpayement 
              let findTransaction1 = await Transaction.findOne({where: {
                stateExternal:"en attente",
                externalId:externalID,
                userRecipient:iduser
              }}).catch((err) => {
                console.log(err);
              });
              TransactionContr.addRechargeTransactionCrypto(findTransaction1);
              // First, check to make sure that the destination account exists.
              // You could skip this, but if the account does not exist, you will be charged
              // the transaction fee when the transaction fails.
                  let changeStatusCompleted= "Completed";
                  findTransaction1.update({stateExternal:changeStatusCompleted});
                  let usertransaction = await User.findOne({
                    where: { publicKey: iduser },
                  }).catch((err) => {
                    console.log(err);
                  });
                  let oldOzp=usertransaction.OZP;
                  let totalOZP = usertransaction.OZP + parseInt(findTransaction1.amount);
                  let userTotalOZP = await usertransaction.update({ OZP: totalOZP });
                  let transactiondata= {
                    userId:iduser,
                    transactionid:externalID,
                    oldozp:oldOzp,
                    newozp:totalOZP
                  }
                  let histoTransactionUser= await histoTransactionUsers.createHistoUserTransaction(transactiondata);
                  res.status(200).json({message: "Mise à jours faite"});          
            }
            else{
              res.status(500).json({message:"Erreur avec coinpayement"});
            };
  }
  else {
    res.status(500).json({message:"Pas de transaction en attente"});
  }
}


module.exports.cancelTransactionCrypto= async (req,res) => {
  let url=req.url;
  let idtransaction=url.split('='|| '?');
  let iduser=idtransaction[1];
  let datatransaction=idtransaction[2];
   datatransaction=datatransaction; 
   datatransaction= new Date(datatransaction-4);
  iduser=iduser.split('?');
  iduser=iduser[0];
  //console.log(datatransaction, iduser);
   //on recherche la transaction de cette id de coinpayement 
   let gettransacpending =await Transaction.findOne({ where: {
    stateExternal:"en attente",
    userRecipient:iduser,
    createdAt: datatransaction
  }
  }).catch((err)=>{
    console.log(err);
  });
 // console.log(gettransacpending);
  let externalID= gettransacpending.dataValues.externalId; 
  let coinpayement= await this.getTransactionInfoCoinV(externalID);
  //console.log(coinpayement);
  let statuscoinpayement=coinpayement.status;
 
  //console.log(externalID) ;
     //onverifie le code du status chez coinpayement
    if (statuscoinpayement<0)
    {
       //on recherche la transaction de cette id de coinpayement 
       let findTransactionCancel = await Transaction.findOne({where: {
        stateExternal:"en attente",
        externalId:externalID,
        userRecipient:iduser
      }}).catch((err) => {
        console.log(err);
      });
      //console.log(findTransactionCancel);
      let changeStatusCancel= "Cancel";
      findTransactionCancel.update({stateExternal:changeStatusCancel});
      res.status(200).json({message: "Mise à jours faite"});          
    }
    else{
      res.status(500).json({message:"Erreur avec coinpayement"}); 
    };
}




function pause(ms){
  return new Promise(resolve => setTimeout(resolve,ms))
}