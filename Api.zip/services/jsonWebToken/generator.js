const jwt = require("jsonwebtoken");

// We generate a token for the user
generateToken = (user, res) => {
  const token = jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, {
    expiresIn: "1800s",
  });
  res.cookie("token", token);
  res.status(200).json({ message: "Logged in successfully 😊 👌", token });
};

module.exports = generateToken;
