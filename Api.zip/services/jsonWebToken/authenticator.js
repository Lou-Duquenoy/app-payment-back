const jwt = require("jsonwebtoken");

// We get the token from the headers of the front end request
function verifyAuth(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1]; //we use split method because of the Bearer word in the header
  console.log("le token de req.headers " + token);

  if (!token) {
    console.log(token);
    return res.sendStatus(401);
  }

  // We check if the token corresponds to the user, if it's ok, we authenticate him
  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) {
      console.log(err);
      return res.sendStatus(401);
    }

    req.user = user;
    next();
  });
}

module.exports = verifyAuth;
