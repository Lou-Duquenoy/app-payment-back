// const express = require("express");
// const router = express.Router();
// const {
//   testCoin1,
//   cryptoPrice,
//   coinBalancesCrypto,
//   coinpayementTransactionCreate,
//   getTransactionInfoCoin,
//   verifyStateTransaction,
//   transactionIsSucceful,
//   successtransaction,
//   cancelTransactionCrypto,
// } = require("../controllers/coinpayements.js");

// router.post("/", testCoin1);
// router.post("/price", cryptoPrice);
// router.post("/balancescrypto", coinBalancesCrypto);
// router.post("/create_transaction_crypto", coinpayementTransactionCreate);
// router.post("/coininfotransaction", getTransactionInfoCoin);
// router.get("/verifyStateTransaction", verifyStateTransaction);
// router.get("/cancelTransaction", transactionIsSucceful);
// router.post("/successtransaction", successtransaction);
// router.post("/canceltransaction", cancelTransactionCrypto);

// module.exports = router;
