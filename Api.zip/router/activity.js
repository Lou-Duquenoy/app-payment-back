// const express = require("express");
// const router = express.Router();
// const {
//   indexActivities,
//   addActivities,
//   myActivities,
//   updateMyActivities,
//   showIdActivities,
//   findActivities,
//   activityProxyUser,
// } = require("../controllers/activity/activities");

// router.post("/", indexActivities);
// router.post("/addmyactivities", addActivities);
// router.post("/myactivities", myActivities);
// router.post("/updateMyActivities", updateMyActivities);
// router.post("/showIdActivities", showIdActivities);
// router.post("/findactivities", findActivities);
// router.post("/proximity", activityProxyUser);

// module.exports = router;
