// const express = require("express");
// const router = express.Router();
// const { connectedUbble,viewstateUserUbble } = require("../controllers/KYC");

// router.post("/", connectedUbble);
// router.post("/viewresult", viewstateUserUbble);

// module.exports = router;
