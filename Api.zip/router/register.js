const express = require("express");
const router = express.Router();
const {
  sendRegisterEmail,
  sendRegisterEmailTest,
  sendRegisterSMS,
  createUser,
  verifyCode,
	
} = require("../controllers/register");
router.post("/sendRegisterEmail", sendRegisterEmail);
router.post("/sendRegisterEmailTest", sendRegisterEmailTest);
router.post("/sendRegisterSMS", sendRegisterSMS);
router.post("/createUser", createUser);
router.post("/verifyCode", verifyCode);

module.exports = router;
