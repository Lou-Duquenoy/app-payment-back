/*const Sequelize = require("sequelize");
const connexion = require("../database");

const Activity_Category = connexion.define(
  "Activity_Categories",
  {
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true,
    },

    name: {
      type: Sequelize.VARCHAR(100),
      allowNull: false,
    },	
  },
  {
    freezeTableName: true  Ensure that the name of the table will be exactly the one passed as argument in the connexion.define() function ,
    timestamps: false,
  }
);


module.exports = Activity_Category;