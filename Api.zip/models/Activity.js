/*const Sequelize = require("sequelize");
const connexion = require("../database");

const Activity = connexion.define(
  "Activities",
  {
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true,
    },

    picture: {
      type: Sequelize.STRING,
      allowNull: false,
    },
	  
	name: {
    type: Sequelize.VARCHAR(100),
    allowNull: false,
    },
	  
	description: {
    type: Sequelize.TEXT,
    allowNull: false,
    },

	minimuPrice: {
    type: Sequelize.INT(11),
    allowNull: true,
    },
	  
	rate: {
    type: Sequelize.INT(2),
    allowNull: true,
    },
	  
	logo: {
    type: Sequelize.STRING,
    allowNull: true,
    },
	
  },
  {
    freezeTableName: true  Ensure that the name of the table will be exactly the one passed as argument in the connexion.define() function ,
    timestamps: false,
  }
);

Activity.hasOne(Activity_Category);
Activity_Category.belongsTo(Activity);

Activity.hasOne(Address);
Address.belongsTo(Activity);


module.exports = Activity;