/*const Sequelize = require("sequelize");
const connexion = require("../database");

const Address = connexion.define(
  "Addresses",
  {
    id: {
      type: Sequelize.BIGINT,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true,
    },

    country: {
      type: Sequelize.VARCHAR(200),
      allowNull: false,
    },
	  
	city: {
    type: Sequelize.VARCHAR(200),
    allowNull: false,
    },
	  
	postCode: {
    type: Sequelize.INT(6),
    allowNull: false,
    },

	streetNumber: {
    type: Sequelize.INT(4),
    allowNull: false,
    },
	  
	streetName: {
    type: Sequelize.TEXT,
    allowNull: false,
    },
	
  },
  {
    freezeTableName: true  Ensure that the name of the table will be exactly the one passed as argument in the connexion.define() function ,
    timestamps: false,
  }
);


module.exports = Address;